import time

import xlrd as xl

class ArKarton():
    def __init__(self, file=None, progress=None):
        self.file = file
        self.progress = progress

    def read_xls(self):
        book = xl.open_workbook(filename=self.file)
        sheet = book.sheet_by_index(0)

        len_column = sheet.ncols
        len_row = sheet.nrows

        dict_column = {}
        dict_row = [0] * len_column
        dict_sort = {}
        for count in range(len_row):
            for i in range(len_column):
                dict_row[i] = sheet.cell_value(count, i)
            dict_column[count] = list(dict_row)
            time.sleep(0.00001)
            self.progress.setValue(count)

        for i in range(len_row):
            for j in range(len_column):
                if dict_column[i][j] == 'EACH':
                    dict_sort[i] = [
                        elem for elem in dict_column[i]
                        if elem != ' '
                        if elem != ''
                        if elem != 'EACH'
                        if elem != 'TOTAL'
                    ]

        sorted_list = sorted(dict_sort.values(), key=lambda x: x[1])

        return sorted_list
