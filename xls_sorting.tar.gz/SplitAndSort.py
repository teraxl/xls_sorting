#!/usr/bin/python3
#coding: windows-1251
from Titan import Titan

xl = Titan(file="titan.xlsx")
xl.read_xlsx()

