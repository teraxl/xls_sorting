import time
import openpyxl as xl


class Titan():
    def __init__(self, file=None, progress=None):
        self.file = file
        self.progress = progress

    def read_xlsx(self):
        book = xl.load_workbook(filename=self.file)
        sheet = book.active

        len_column = sheet.max_column
        len_row = sheet.max_row

        dict_column = {}
        dict_row = [0] * len_column
        dict_sort = {}
        for count in range(1, len_row):
            for i in range(1, len_column):
                dict_row[i] = sheet.cell(count, i).value
            dict_column[count] = list(dict_row)
            time.sleep(0.00001)
            self.progress.setValue(count)

        for i in range(1, len_row):
            for j in range(1, len_column):
                if dict_column[i][j] == 'НАИМЕНОВАНИЕ ПРОДУКТА':
                    for col in range((i + 2), len_row - 1):
                        for row in range(j, len_column):
                            dict_sort[col] = [
                                elem for elem in dict_column[col]
                                if elem is not None
                                if elem != 0
                            ]

        sorted_list = sorted(dict_sort.values(), key=lambda x: x[0])

        # for i in range(len(sorted_list)):
        #     print(sorted_list[i])

        return sorted_list


