# coding=utf-8

from PyQt5 import QtWidgets
from PyQt5.QtWidgets import QFileDialog
from PyQt5.QtCore import Qt
import sys
from GuiCount import Ui_Form
import ArKarton
from Titan import Titan


class MyTitan(QtWidgets.QWidget):

    def __init__(self):
        super(MyTitan, self).__init__()
        self.ui = Ui_Form()
        self.ui.setupUi(self)
        self.ui.pushButton.clicked.connect(self.openFileDialogArKarton)
        self.ui.pushButton_2.clicked.connect(self.openFileDialogTitan)

        self.visableButton()

    def visableButton(self):
        if (self.ui.lineEdit.text() and self.ui.lineEdit_2.text()) != "":
            self.ui.pushButton_3.setEnabled(True)
        else:
            self.ui.pushButton_3.setEnabled(False)

    def loadFileArKarton(self, file):
        xl = ArKarton.ArKarton(file, self.ui.progress)
        sp = str(file).split("/")
        self.ui.progress.setFormat(sp[int(len(sp)) - 1] + " загружен --> " + "%p%")
        listVal = xl.read_xls()
        self.visableButton()


    def openFileDialogArKarton(self):
        option = QFileDialog.Options()
        filename = QFileDialog.getOpenFileName(self, "Выберете файл от АО АР Картон", "", "ArKarton (*.xls)", options=option)
        self.ui.lineEdit.setText(filename[0])
        self.loadFileArKarton(filename[0])

    def loadFileTitan(self, file):
        xl = Titan(file, self.ui.progress)
        sp = str(file).split("/")
        self.ui.progress.setFormat(sp[int(len(sp)) - 1] + " загружен --> " + "%p%")
        listVal = xl.read_xlsx()
        self.visableButton()


    def openFileDialogTitan(self):
        option = QFileDialog.Options()
        filename = QFileDialog.getOpenFileName(self, "Выберете файл от ООО Титан", "", "Титан (*.xlsx)", options=option)
        self.ui.lineEdit_2.setText(filename[0])
        self.loadFileTitan(filename[0])


app = QtWidgets.QApplication([])
application = MyTitan()
application.setWindowFlags(
    Qt.Window |
    Qt.WindowMinimizeButtonHint |
    Qt.WindowCloseButtonHint
)
application.show()

sys.exit(app.exec())
